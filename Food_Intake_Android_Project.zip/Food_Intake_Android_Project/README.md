# Food Intake Tracker — Android project

This project wraps the food-tracker interface in an Android WebView. It includes the 22 food items imported from the supplied Excel workbook, 10 meal slots, daily nutrition dashboard, custom food database, CSV export and JSON backup/restore.

## Build a debug APK using GitHub Actions

This environment does not have the Android SDK/build tools needed to compile and sign an APK locally, so this project includes a GitHub Actions workflow that builds one for you.

1. Create a GitHub repository and upload all files in this project to its `main` branch.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and press **Run workflow** (or let it run automatically after pushing).
4. Open the completed workflow run and download the **Food-Intake-Tracker-APK** artifact.
5. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
6. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from that source.

This is a debug APK for personal use, not a Play Store release. Nutrition entries are stored locally in the app's WebView storage. Use the built-in JSON backup feature to protect your data.
